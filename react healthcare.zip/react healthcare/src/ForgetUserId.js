import React, { Component } from 'react'
import {Modal,Button,Row,Col,Form} from 'react-bootstrap'
class ForgetUserId extends Component {
    constructor(props) {
      super(props)
      this.handleSubmit=this.handleSubmit.bind(this);
      this.state={
          question1 :'',
          question2 : '',
          question3 : '',
          errors: {}
      }
    
    }
     handleValidation = () => {
        
        let errors = {};
        let formIsValid = true;
        //Name
        console.log(1);
        if (typeof this.state.question1 !== "undefined") {
            if (!this.state.question1) {
                formIsValid = false;
                errors["qustion1"] = "Cannot be empty";
              }    
        }
        
        if (typeof this.state.question2 !== "undefined") {
            if (!this.state.question2) {
                formIsValid = false;
                errors["qustion2"] = "Cannot be empty";
              }    
        }
        
        if (typeof this.state.question3 !== "undefined") {
            if (!this.state.question3) {
                formIsValid = false;
                errors["qustion3"] = "Cannot be empty";
              }    
        }
        console.log(errors);
        this.setState({errors:errors})
        return formIsValid;
    }
    handleSubmit =(e)=>{
        e.preventDefault();
        if(this.handleValidation)
        {
        fetch(process.env.REACT_APP_API,
            {
            method:"POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                empId:0,
                empName:e.target.empName.value,
                designation:e.target.designation.value,
                salary:e.target.salary.value
                })
            })
            .then(res=>res.json())
            .then(result=>console.log(result));
        }
    }
  render() {      
    return (
      <div className='container'>
          <Modal {...this.props} size="lg" centered>
            <Modal.Header closeButton>
                <Modal.Title >
                    Forgot UserId
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                    <Form className='m-auto' style={{width:"80%"}}> 
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                                What is your first Pet Name?
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="Enter pet name" value={this.state.question1} onChange={(e)=>this.setState({question1:e.target.value})} />
                                <span style={{ color: "red" }}>{this.state.errors["question1"]}</span>
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                            Which is your favorite city?
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="Enter City Name"  value={this.state.question2} onChange={(e)=>this.setState({question2:e.target.value})}/>
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                            What is school name?
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="Enter school Name"  value={this.state.question3} onChange={(e)=>this.setState({question3:e.target.value})}/>
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                        <Col sm="2"></Col>
                        <Col sm="5">
                        <Button className='btn btn-success'>Submit</Button>
                        </Col>
                        <Col sm="5">
                        <Button className='btn btn-success' varient="danger" onClick={this.props.onHide}>
                                    Close                </Button>
                                    </Col>
                        </Form.Group>

                    </Form>
                    
            </Modal.Body>
          </Modal>

      </div>
    )
  }
}

export default ForgetUserId