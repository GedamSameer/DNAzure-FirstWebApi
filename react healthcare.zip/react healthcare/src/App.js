import React  from "react";
import {BrowserRouter, Link, Route,Routes} from 'react-router-dom';
import "./App.css";
import Homepage from "./Homepage";
import AdminRegister from "./AdminRegister";
import CustomerRegister from "./CustomerRegister";
import CustomerSignin from "./CustomerSignin";
import AdminSignin from "./AdminSignin";
import CustomerHomepage from "./CustomerHomepage";
import OrderMedicine from "./OrderMedicine";
import SearchMedicine from "./SearchMedicine";
import SecretQuetions from "./SecretQuestions";
import AdminHomepage from "./AdminHomepage";
import AvailableMedicine from "./AvailableMedicine";
import AddMedicine from './AddMedicine'; 
import ViewOrder from "./ViewOrder";
import Payment from "./Payment";
import MedicineModal from "./MedicineModel";
const App = () => {
  return(
    <>  
    <BrowserRouter>
    <div>
    <Routes>    
   <Route exact path="/" element={<Homepage/>}/>
    <Route exact path="/Homepage" element={<Homepage/>}/>
    <Route exact path="/CustomerRegister" element={<CustomerRegister/>}/>
    <Route exact path="/AdminRegister" element={<AdminRegister/>}/>
    <Route exact path="/CustomerSignin" element={<CustomerSignin/>}/>
    <Route exact path="/AdminSignin" element={<AdminSignin/>}/>
  <Route exact path="./SecretQuestions.js" element={<SecretQuetions/>}/>
  <Route exact path="/AdminHomepage" element={<AdminHomepage/>}/>

   <Route exact path="/AdminHomepage" element={<AdminHomepage/>}/>
    <Route exact path="/AvailableMedicine" element={<AvailableMedicine/>}/>
  <Route exact path="/AddMedicine" element={<AddMedicine/>}/>
    
   <Route exact path="/CustomerHomepage" element={<CustomerHomepage/>}/>
    <Route exact path="/SearchMedicine" element={<SearchMedicine/>}/>
  <Route exact path="/OrderMedicine" element={<OrderMedicine/>}/>
  <Route exact path="/Payment" element={<Payment/>}/>


    </Routes>
    </div>
    </BrowserRouter>
    
    </>
  );
};
export default App;