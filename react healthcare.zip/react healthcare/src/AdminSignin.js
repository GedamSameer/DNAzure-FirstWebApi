import React, { Component } from "react";
import { Form, Button,Row ,Col} from "react-bootstrap";
import {Container,Navbar} from "react-bootstrap"


import { Link } from "react-router-dom";
import ForgotAdminId from "./ForgotAdminId";
import ForgotPasswordAdmin from "./ForgotPasswordAdmin";

export default class AdminSignin extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      pass: "",
      showForgetUserIdShow: false,
      showForgetPasswordShow: false,
      errors:{}
    };
  }
  handleValidations = () =>{
    let errors = {};
    let formIsValid = true;
    
    if (typeof this.state.email !== "undefined") {
        if (!this.state.email) {
            formIsValid = false;
            errors["email"] = "Please, Enter a Value";
          }    
    }
    if (typeof this.state.pass !== "undefined") {
      if (!this.state.pass) {
          formIsValid = false;
          errors["pass"] = "Please, Enter a Value";
        }    
  }
    this.setState({errors:errors});
    return formIsValid;  
  }
  resetForm = () => {
    this.setState({
      email: "",
      pass: "",
      showForgetUserIdShow: false,
      showForgetPasswordShow: false,
      errors:{}
    })
 }

  buttonClick = async (e) => {
    e.preventDefault();
    if(this.handleValidations())
    {
      let obj = {
        "id": 0,
        "firstName": "string",
        "lastName": "string",
        "age": 0,
        "contactNo": "string",
        "gender": "string",
        "emailId": "string",
        "adminId": this.state.email,
        "password": this.state.pass,
        "que1Ans": "string",
        "que2Ans": "string",
        "que3Ans": "string"

      }
      const data = await fetch("http://localhost:5284/api/Token/Admins",
      {
      method:"POST",
      headers:{
          'Accept':'application/json',
          'Content-Type':'application/json'
      },
      body:JSON.stringify(obj)
      })
      .then(res=>res.json())
      .then(result=>result);
      if(data==="Invalid credentials"){
        this.resetForm();
        this.setState({errors:{pass:"Enter valid password or username"}})
      }
      else{
        sessionStorage.setItem("token",data[0])
        sessionStorage.setItem("id",data[1])
        sessionStorage.setItem("name",data[2])
        window.location = "./AdminHomepage"
      }

    }
  };
  render() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("id");
    sessionStorage.removeItem("name");

    let showModelClose =()=>this.setState({showForgetUserIdShow:false});
    let showPassModelClose =()=>this.setState({showForgetPasswordShow:false});

    return (
      <>
      <Navbar className="bg-light p-1">
        <Container>
    <Navbar.Brand className="text-dark " href="#SearchMedicine"><h3>Admin Sign In</h3></Navbar.Brand>
   
    </Container>

      </Navbar>
    <Form className="m-auto mt-12 my-auto justify-Content" style={{ width: "30%",height: "100vh"}}>
    <h3 className="text-center mb-2 text-black margin-mt-5 pt-5" style={{width: "100%" }}><u>ADMIN SIGN IN</u> </h3>
   <Form.Group className="mb-3 col-12" controlId="formBasicEmail">
     <Form.Label><b>Admin Id</b></Form.Label>
     <Form.Control
       type="email"
       required
       placeholder="Enter Admin Id"
       value={this.state.email}
       name="customerid"
       onChange={(e) => {
         this.setState({ email: e.target.value });
       }}
     />
   </Form.Group>

   <Form.Group className="mb-3 col-12" controlId="formBasicPassword">
     <Form.Label><b>Password</b></Form.Label>
     <Form.Control
       type="password"
       required
       placeholder="Password"
       value={this.state.pass}
       name="pass"
       onChange={(e) => {
         this.setState({ pass: e.target.value });
       }}
     />
   </Form.Group>
   <div className="row m-2">
     <Button
       className="col-4 btn-dark"
       variant="primary"
       type="submit "
       onClick={this.buttonClick}
     >
       Login
     </Button>
     <div className="col-4"></div>
     <Button className="col-4 ml-5 btn-success" variant="danger" type="reset" onClick={this.resetForm}>
       Reset
     </Button>
   </div>
   <div className="row mb-2">
     <Form.Group controlId="formBasicPassword">   
     <Row> 
       <Col className="p-0 col-5">     
       <Button
       variant="link"
         className="link-primary"
         onClick={() => this.setState({ showForgetUserIdShow: true })}>
         <b>Forgot Admin Id?   </b>            
       </Button>
       <ForgotAdminId
           show={this.state.showForgetUserIdShow}
           onHide={showModelClose}
         />     
         </Col>
         <Col className="p-1 col-6">    
       <Button        
       variant="link"  
         className="link-primary"
         onClick={() => this.setState({ showForgetPasswordShow: true })}
       >
        <b> Forgot Password?</b>
         
       </Button>

       <ForgotPasswordAdmin
           show={this.state.showForgetPasswordShow}
           onHide={showPassModelClose}
         />    
         </Col>
         </Row>     
     </Form.Group>
   </div>

  
 </Form>
 </>
 );
  }
}