
import React from "react";

import { Link } from "react-router-dom";

const Customer = () => {
    return (
    <>
    <div id="Customer">
    <Link to="/Admin">Admin</Link>
    <Link to="/Customer">Customer</Link>
    <form>
    <label>
    CustomerId:
    <input type="text" name="customerid" />
    </label>
    <label>
    Password:
    <input type="text" name="password" />
    </label>
    <input type="submit" value="Submit" />
    </form>
    </div>
    </>);
};
export default Customer;