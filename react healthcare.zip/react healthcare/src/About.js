import React from "react";
import { NavLink } from "react-router-dom";

const About = () => {
    return (<>
    <h1>This is About Page</h1>
    <NavLink to="/">About</NavLink>
    <NavLink to="/Contact">Contact</NavLink>
    </>
    );
};
export default About;