import React, { Component } from 'react'
import {Modal,Button,Row,Col,Form} from 'react-bootstrap'
class ForgetPassword extends Component {
    constructor(props) {
      super(props)
      this.handleSubmit=this.handleSubmit.bind(this);
    
    }
    handleSubmit =(e)=>{
        e.preventDefault();
        fetch(process.env.REACT_APP_API,
            {
            method:"POST",
            headers:{
                'Accept':'application/json',
                'Content-Type':'application/json'
            },
            body:JSON.stringify({
                empId:0,
                empName:e.target.empName.value,
                designation:e.target.designation.value,
                salary:e.target.salary.value
                })
            })
            .then(res=>res.json())
            .then(result=>console.log(result));
    }
  render() {      
    return (
      <div className='container'>
          <Modal {...this.props} size="lg" centered>
            <Modal.Header closeButton>
                <Modal.Title >
                    Forgot Password
                </Modal.Title>
            </Modal.Header>
            <Modal.Body>
                    <Form className='m-auto' style={{width:"80%"}}> 
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                                User ID
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="Enter User Id" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                             New Password
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="enter password" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                            <Form.Label column sm="5">
                            Confirm Password
                            </Form.Label>
                            <Col sm="7">
                                <Form.Control type="text" placeholder="enter confirm password" />
                            </Col>
                        </Form.Group>
                        <Form.Group as={Row} className="mb-3" controlId="formPlaintext">
                        <Col sm="2"></Col>
                        <Col sm="5">
                        <Button className='btn btn-success'>Submit</Button>
                        </Col>
                        <Col sm="5">
                        <Button className='btn btn-success' varient="danger" onClick={this.props.onHide}>
                                    Close                </Button>
                                    </Col>
                        </Form.Group>

                    </Form>
                    
            </Modal.Body>
          </Modal>

      </div>
    )
  }
}

export default ForgetPassword