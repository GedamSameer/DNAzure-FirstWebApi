
import React from "react";
import './Admin.css';

import { NavLink } from "react-router-dom";

const Admin = () => {
    return (
    <>
    <div id="Admin">
    <NavLink exact activeClassName="active_class" to="/Admin">Admin</NavLink>
    <NavLink exact activeClassName="active_class" to="/Customer">Customer</NavLink>
    <form>
    <label>
    AdminId:
    <input type="text" name="userid" />
    </label>
    <label>
    Password:
    <input type="text" name="password" />
    </label>
    <input type="submit" value="Submit" />
    <label>Not registered?</label>
    <button onClick={AdminRegister}>Register</button>
    </form>
    </div>
    </>);
};
export default Admin;