
import React from "react";

import { Link } from "react-router-dom";

const Contact = () => {
    return (
    <>
    <h1>This is Contact Page</h1>
    <Link to="/">About</Link>
    <Link to="/Contact">Contact</Link>
    </>);
};
export default Contact;