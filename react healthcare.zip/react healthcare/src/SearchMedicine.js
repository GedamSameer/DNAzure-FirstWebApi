import React, { useState } from "react";
import {
  Form,
  Button,
  Row,
  Col,
  Table,
  Alert,
  Dropdown,
  Navbar,
  Container,
  NavDropdown,
  Nav,
  FormControl,
  InputGroup,
  SplitButton,
} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from "react-router-dom";

import { useEffect } from "react";

const SearchMedicine = () => {
  const [medicinename, setMedicineName] = useState("");
  const [type, setType] = useState("");
  const [errors, setErros] = useState({});
  const [helpData, setHelpData] = useState([]);

  const handleValidationName = () => {
    let errors = {};
    let formIsValid = true;

    if (typeof medicinename !== "undefined") {
      if (!medicinename) {
        formIsValid = false;
        errors["medicinename"] = "Please, Enter a Value";
      }
    
    }
    setErros(errors);
    return formIsValid;

  };

  const handleValidationType = () => {
    let errors = {};
    let formIsValid = true;

    if (typeof type !== "undefined") {
      if (!type) {
        formIsValid = false;
        errors["type"] = "Please, Enter a Value";
      }
    
    }
    setErros(errors);
    return formIsValid;

  };

  const handleSearchbyType = async (e) => {
    e.preventDefault();
    if (handleValidationType()) {
      const d = await fetch(`http://localhost:5284/api/Medicines/name/${type}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then((res) => res.json())
        .then((result) => result);
      setHelpData(d);
      console.log(helpData)
    }
  };

  const handleSearchbyName = async (e) => {
    e.preventDefault();
    if (handleValidationName()) {
      const d = await fetch(`http://localhost:5284/api/Medicines/name/${medicinename}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
      })
        .then((res) => res.json())
        .then((result) => result);
      setHelpData(d);
      console.log(helpData)
    }
  };
  let table ;
  const data = helpData;
  let check =() => {
    if(data.length>0)
    {
        table = data.map(record => 
        (<tr key={record.id}>
          <td>{record.id}</td>
          <td>{record.medicineName}</td>
          <td>{record.manufacturer}</td>
          <td>{record.quantityPerStripPac}</td>
          <td>{record.mrpForEachQuantity}</td>
          <td>{record.manufacturingDate}</td>
          <td>{record.expiryDate}</td>
          <td>{record.type}</td>
          <td>{record.availableQuantity}</td>
        </tr>
        ))
    }
}
  
   
  return (
    <>
      <Form className="m-auto float-centre mt-5" style={{ width: "80%" }}>
        <h1 className="text-center mb-4 text-dark" style={{ width: "100%" }}>
        <u> <h3>SEARCH MEDICINE</h3> </u>
        </h1>
        <Form.Group as={Row} className="mb-3" controlId="formPass">
          <Form.Label className="d-flex justify-content-start" column sm="2">
            Search Medicine By Type
          </Form.Label>
          <Col sm="5">
            <Form.Select required onChange={(e) => setType(e.target.value)}>
              <option value="Capsule">Capsule</option>
              <option value="Tablet">Tablet</option>
              <option value="Liquid">Liquid</option>
              <option value="Gas">Gas</option>
              <option value="Other">Other</option>
            </Form.Select>
          </Col>
          <Col sm="2">
            <span style={{ color: "red" }}>{errors["type"]}</span>
          </Col>
          <Col sm="3">
            <Button
              className="col-12 btn-success"
              type="submit"
              value="submit"
              onClick={handleSearchbyType}
            >
              {" "}
              Search{" "}
            </Button>
          </Col>
        </Form.Group>

        <Form.Group as={Row} className="mb-3" controlId="formPass">
          <Form.Label className="d-flex justify-content-start" column sm="2">
            Search Medicine by Name
          </Form.Label>
          <Col sm="5">
            <Form.Control
              required
              type="search"
              placeholder="Enter Medicine Name"
              onChange={(e) => setMedicineName(e.target.value)}
            />
          </Col>
          <Col sm="2">
            <span style={{ color: "red" }}>{errors["medicinename"]}</span>
          </Col>

          <Col sm="3">
            <Button
              className="col-12 btn-success"
              type="submit"
              value="submit"
              onClick={handleSearchbyName}
            >
              {" "}
              Search{" "}
            </Button>
          </Col>
        </Form.Group>
      </Form>
      <Table className='mt-4 text-white' variant="dark" bordered size='sm'>

        <thead>
        <tr><th colSpan={9} className="text-white text-center">Available Medicine Requested</th></tr>
        <tr><th>Id</th>
            <th>Medicine Name</th>
            <th>Manufacturer</th>
            <th>Quantity per strip</th>
            <th>MRP per quantity</th>
            <th>Manufacturing Date</th>
            <th>Expiry Date</th>
            <th>Type</th>
            <th>Available Quantity</th>
        </tr>
        </thead>
        <tbody>
            {check()}
            {table}
        </tbody>
        </Table>


      
    </>
  );
};
export default SearchMedicine;
