import React, { useState } from 'react'
import { Form, Button, Row, Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'

import validator from 'validator';
import {Container,Navbar} from "react-bootstrap"
function AddMedicine() {
    const setDate = (separator = '-') => {
        let newDate = new Date();
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();

        return `${year}${separator}${month < 10 ? `0${month}` : `${month}`}${separator}${date}`
    }



    const [medicinename, setMedicineName] = useState("");
    const [manufacturer, setManufacturer] = useState("");
    const [quantityperstrip, setQuantityPerStrip] = useState("");
    const [mrpperquantity, setMrpPerQuantity] = useState("");
    const [manufacturingdate, setManufacturingDate] = useState(setDate);
    const [expirydate, setExpiryDate] = useState(setDate);
    const [type, setType] = useState("Capsule");
    const [availablequantity, setAvailableQuantity] = useState("");

    const [errors, setErros] = useState({});

    const resetForm = () => {

        setMedicineName("");
        setManufacturer("");
        setQuantityPerStrip("");
        setMrpPerQuantity("");
        setManufacturingDate("Male");
        setExpiryDate("");
        setType("");
        setAvailableQuantity("");
        setErros({});

    }
    const getUsername = () => {
        let back = () =>window.location = `/${sessionStorage.getItem("userType").toLowerCase()}dashboard`
        let usernames =fetch("http://localhost:5284/api/Medicines",
            {
                method: "GET",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(result => result);
        return  usernames;
    }

    const handleValidation =  () => {

        let errors = {};
        let formIsValid = true;

        if (typeof medicinename !== "undefined") {
            if (!medicinename) {
                formIsValid = false;
                errors["medicinename"] = "Please, Enter a Value";
            }
        }
        if (typeof manufacturer !== "undefined") {
            if (!manufacturer) {
                formIsValid = false;
                errors["manufacturer"] = "Please, Enter a Value";
            }
        }

        if (typeof quantityperstrip !== "undefined") {
            if (!quantityperstrip) {
                formIsValid = false;
                errors["quantityperstrip"] = "Please, Enter a Value";
            }
            else if (!quantityperstrip.match(/^[0-9]*$/)) {
                formIsValid = false;
                errors["quantityperstrip"] = "Only Numbers";
            }

        }
        if (typeof mrpperquantity !== "undefined") {
            if (!mrpperquantity) {
                formIsValid = false;
                errors["mrpperquantity"] = "Please, Enter a Value";
            }
            else if (!mrpperquantity.match(/^[0-9]*$/)) {
                formIsValid = false;
                errors["mrpperquantity"] = "Only numbers";
            }
        }
        if (typeof manufacturingdate !== "undefined") {
            if (!manufacturingdate) {
                formIsValid = false;
                errors["manufacturingdate"] = "Please, Enter a Value";
            }

        }
        if (typeof expirydate !== "undefined") {
            if (!expirydate) {
                formIsValid = false;
                errors["expirydate"] = "Please, Enter a Value";
            }

        }
        if (typeof type !== "undefined") {
            if (!type) {
                formIsValid = false;
                errors["type"] = "Please, Enter a Value";
            }
        }
        if (typeof availablequantity !== "undefined") {
            if (!availablequantity) {
                formIsValid = false;
                errors["availablequantity"] = "Please, Enter a Value";
            }

            else if (!availablequantity.match(/^[0-9]*$/)) {
                formIsValid = false;
                errors["availablequantity"] = "Only numbers";
            }
        }

  
        setErros(errors);
        return  formIsValid;
    }
   

 const handleSubmit = (e) => {
        e.preventDefault();
        if (handleValidation()) {
            let obj = {
                
               "id": 0,
                "medicineName": medicinename,
                "manufacturer": manufacturer,
                "quantityPerStripPac": quantityperstrip,
                "mrpForEachQuantity": mrpperquantity,
                "manufacturingDate": manufacturingdate,
                "expiryDate": expirydate,
                "type": type,
                "availableQuantity": availablequantity
            }
            fetch("http://localhost:5284/api/Medicines",
                {
                    method: "POST",
                    headers: {
                     'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(obj)
                })
                .then(res => res.json())
                .then(result => console.log(result));
            window.location = "./AvailableMedicine"

        }

    } 
    return (
        <>
  <Navbar className="bg-light p-1">
  <Container>
    <Navbar.Brand className="text-dark " href="#SearchMedicine"><h1>Add Medicine</h1></Navbar.Brand>
    <Button variant="dark" href="./AvailableMedicine" className='float-end btn-success mx-3' > Back </Button>
    </Container>
 </Navbar>

            <Form className='m-auto float-centre mt-5' style={{ width: "80%" }}>
                <h1 className="text-center mb-4 text-dark" style={{ width: "100%" }}><u><i>ADD MEDICINE</i></u></h1>
                <Form.Group as={Row} className="mb-3" controlId="formFirstName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Medicine Name</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='medicinename' type="text" placeholder="Enter Medicine Name" value={medicinename} onChange={(e) => setMedicineName(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["medicinename"]}</span>
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formLastName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>Manufacturer</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='manufacturer' type="text" placeholder="Enter Manufacturer" value={manufacturer} onChange={(e) => setManufacturer(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["manufacturer"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formAge">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Quantity Per Strip</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='quantityperstrip' type="Number" placeholder="Enter Quantity Per Strip" value={quantityperstrip} onChange={(e) => setQuantityPerStrip(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["quantityperstrip"]}</span>
                    </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formContact">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> MRP Per Quantity</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="Number" placeholder="Enter MRP Per Quantity" required value={mrpperquantity} onChange={(e) => setMrpPerQuantity(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["mrpperquantity"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} required className="mb-3" controlId="formGender">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Manufacturing Date</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="Date" name='manufacturingdate' max={setDate()} required value={manufacturingdate} onChange={(e) => { setManufacturingDate(e.target.value); console.log(manufacturingdate) }} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["manufacturingdate"]}</span>
                    </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formEmailId">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Expiriy Date</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="Date" name='expirydate' min={setDate()} required value={expirydate} onChange={(e) => { setExpiryDate(e.target.value); console.log(expirydate) }} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["expirydate"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formPass">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>Available Quantity</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="Number" placeholder="Enter Available Quantity" value={availablequantity} onChange={(e) => setAvailableQuantity(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["availablequantity"]}</span>
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formPass">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>   Medicine Type</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Select required onChange={(e) => setType(e.target.value)}>
                            <option value="Capsule">Capsule</option>
                            <option value="Tablet">Tablet</option>
                            <option value="Liquid">Liquid</option>
                            <option value="Gas">Gas</option>
                            <option value="Other">Other</option>
                        </Form.Select>
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["availablequantity"]}</span>
                    </Col>

                </Form.Group>


                <Form.Group as={Row} className="mb-3" controlId="formSubmit">
                    <Form.Label column sm="4">
                    </Form.Label>
                    <Col sm="3">
                        <Button className="col-12 btn-success" type="submit" value="submit" onClick={handleSubmit}> <b>Submit</b> </Button>
                        
                    </Col>
                    <Col sm="3">
                        <Button className='btn btn-danger col-12' onClick={resetForm}><b>Cancel</b></Button>
                    </Col>
                    <Form.Label column sm="2">
                    </Form.Label>
                </Form.Group>
               
            </Form>
        </>
    );
}

export default AddMedicine
