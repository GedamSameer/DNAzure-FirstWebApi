import React, { useEffect, useState } from 'react'
import { Form, Button, Row, Col } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import AdminSecretQuestions from './AdminSecretQuestions';
import validator from 'validator';




function OrderMedicine() {
    const setDate = (separator = '-') => {
        let newDate = new Date();
        let date = newDate.getDate();
        let month = newDate.getMonth() + 1;
        let year = newDate.getFullYear();



        return `${year}${separator}${month < 10 ? `0${month}` : `${month}`}${separator}${date}`
    }



    const [madicineList, setMadicineList] = useState([]);
    const [patientname, setPatientName] = useState("");
    const [age, setAge] = useState("");
    const [doctorname, setDoctorName] = useState("");
    const [dateoforder, setDateOfOrder] = useState(setDate);
    const [prescription, setPrescription] = useState("");
    const [medicine, setMedicine] = useState("");
    const [requiredquantity, setRequiredQuantity] = useState("");
    const [errors, setErros] = useState({});
    const [selectedFile, setSelectedFile] = useState(null)



    const resetForm = () => {
        setPatientName("");
        setAge("");
        setDoctorName("");
        setDateOfOrder("");
        setPrescription("");
        setMedicine("");
        setRequiredQuantity("");
        setErros({});

    }
    const handleValidation = () => {
        let errors = {};
        let formIsValid = true;
        if (typeof patientname !== "undefined") {
            if (!patientname) {
                formIsValid = false;
                errors["patientname"] = "Please, Enter a Value";
            }
        }
        if (typeof age !== "undefined") {
            if (!age) {
                formIsValid = false;
                errors["age"] = "Please, Enter a Value";
            }



            else if (!doctorname.match(/^[A-Za-z]*$/)) {
                formIsValid = false;
                errors["doctorname"] = "Only Numbers";
            }
        }



        if (typeof doctorname !== "undefined") {
            if (!doctorname) {
                formIsValid = false;
                errors["doctorname"] = "Please, Enter a Value";
            }



        }
        if (typeof dateoforder !== "undefined") {
            if (!dateoforder) {
                formIsValid = false;
                errors["dateoforder"] = "Please, Enter a Value";
            }



        }
        if (typeof prescription !== "undefined") {
            if (!prescription) {
                formIsValid = false;
                errors["prescription"] = "Please, Enter a Value";
            }



        }
        if (typeof medicine !== "undefined") {
            if (!medicine) {
                formIsValid = false;
                errors["medicine"] = "Please, Enter a Value";
            }



        }
        if (typeof requiredquantity !== "undefined") {
            if (!requiredquantity) {
                formIsValid = false;
                errors["requiredquantity"] = "Please, Enter a Value";
            }




        }




        setErros(errors);
        return formIsValid;
    }
    const onFileChange = event => {
        console.log(event)
        const d = event.target.files[0];
        setPrescription(d.name)




    };
    const handleSubmit = (e) => {
        e.preventDefault();
        if (handleValidation()) {
            let obj = {
                "id": 0,
                "patientName": patientname,
                "age": age,
                "doctorName": doctorname,
                "dateOfOrder": dateoforder,
                "medicine": medicine,
                "prescription": prescription,
                "requiredQuantity": requiredquantity
            }




            fetch("http://localhost:5284/api/Orders",
                {
                    method: "POST",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(obj)
                })
                .then(res => res.json())
                .then(result => console.log(result));
            window.location = "./Payment"


        }
    }
    const getData = async () => {
        const data = await fetch("http://localhost:5284/api/Orders/nameslist").then(res => res.json())

        await setMadicineList([...data]);
    }
    useEffect(() => {
        getData()
    })
    return (
        <>

            <Form className='m-auto float-centre mt-5' style={{ width: "90%" }}>
                <h1 className="text-center mb-4 text-dark" style={{ width: "100%" }}><u><i>ORDER MEDICINE</i></u></h1>
                <Form.Group as={Row} className="mb-3" controlId="formFirstName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Patient Name</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='patientname' type="text" placeholder="Enter Patient Name" value={patientname} onChange={(e) => setPatientName(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["patientname"]}</span>
                    </Col>



                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formLastName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Age</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='age' type="Number" placeholder="Enter Age" value={age} onChange={(e) => setAge(e.target.value)} />
                    </Col>
                    <Col sm="2">



                        <span style={{ color: "red" }}>{errors["age"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formAge">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Doctor Name</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='doctorname' type="text" placeholder="Enter Doctor Name" value={doctorname} onChange={(e) => setDoctorName(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["doctorname"]}</span>
                    </Col>
                </Form.Group>



                <Form.Group as={Row} className="mb-3" controlId="formContact">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Date Of Order</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="Date" disabled placeholder="Enter MRP Per Quantity" required value={dateoforder} onChange={(e) => setDateOfOrder(e.target.value)} />
                    </Col>
                    <Col sm="2">



                        <span style={{ color: "red" }}>{errors["dateoforder"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} required className="mb-3" controlId="formGender">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Upload Prescription</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="file" name='prescription' required onChange={(e) => onFileChange(e)} />
                    </Col>
                    <Col sm="2">



                        <span style={{ color: "red" }}>{errors["prescription"]}</span>
                    </Col>
                </Form.Group>



                <Form.Group as={Row} className="mb-3" controlId="formEmailId">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Select the Medicine</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Select name='medicine' required value={medicine} onChange={(e) => { setMedicine(e.target.value); }} >
                            {madicineList.map(r => {
                                return (
                                    <option value={r}>{r}</option>
                                )
                            })}

                        </Form.Select>
                    </Col>
                    <Col sm="2">



                        <span style={{ color: "red" }}>{errors["medicine"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formPass">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                        <b>Required Quantity</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="Number" placeholder="Enter Required Quantity" value={requiredquantity} onChange={(e) => setRequiredQuantity(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["requiredquantity"]}</span>
                    </Col>



                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formSubmit">
                    <Form.Label column sm="4">
                    </Form.Label>
                    <Col sm="3">
                        <Button className="col-12 btn-success" type="submit" value="submit" onClick={handleSubmit}
                        > <b>Order</b> </Button>



                    </Col>
                    <Col sm="3">
                        <Button className='btn btn-danger col-12' onClick={resetForm}><b>Reset</b></Button>
                    </Col>
                    <Form.Label column sm="2">
                    </Form.Label>
                </Form.Group>



            </Form>
        </>
    );
}



export default OrderMedicine




