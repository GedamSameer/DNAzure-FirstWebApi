import React,{useState} from 'react';
import {Form,Button,Row,Col} from 'react-bootstrap';
import { Link } from 'react-router-dom';

const AdminRegister = () => {
    const [fname,setFName] = useState("");
    const [lname,setLName] = useState("");
    const [contact,setContact] = useState("");
    const [gender,setGender] = useState("Male");
    const [userid,setUserId] = useState("");
    const [usertype,setUserType] = useState("");
    const [confirmpass,setConfirmPass] = useState("");
    const [pass,setPass] = useState("");
    const [errors,setErros] = useState({});
    const fields = {fname:'fname',lname:'lname',contact:'contact',gender:'gender',usertype:'usertype',userid:'userid',pass:'pass',confirpass:'confirmpass'}
    const handleValidation = () => {
        
        let errors = {};
        let formIsValid = true;
        console.log(fname);
        //Name

        if (typeof fname !== "undefined") {
            if (!fname) {
                formIsValid = false;
                errors["fname"] = "Cannot be empty";
              }    
            else if (!fname.match(/^[A-Za-z]*$/)) {
            formIsValid = false;
            errors["fname"] = "Only letters";
          }
        }
        if (typeof lname !== "undefined") {
            if (!lname) {
                formIsValid = false;
                errors["lname"] = "Cannot be empty";
              }    
            else if (!lname.match(/^[A-Za-z]*$/)) {
            formIsValid = false;
            errors["lname"] = "Only letters";
          }

        }
        if (typeof contact !== "undefined") {
            if (!contact) {
                formIsValid = false;
                errors["contact"] = "Cannot be empty";
              }    
            else if (!contact.match(/^[0-9]*$/)) {
            formIsValid = false;
            errors["contact"] = "Only numbers";
            }
            else if (contact.length!==10) {
                formIsValid = false;
                errors["contact"] = "10 Digit number is required";
          }
        }
    
        setErros(errors);
        console.log(errors)
        return formIsValid;
      }

    const handleSubmit = (e) =>
    {
        e.preventDefault();
        if(handleValidation())
        {
       
        console.log(fname);
        console.log(lname);
        console.log(contact);
        console.log(gender);
        console.log(usertype);
        console.log(userid);
        console.log(pass);
        console.log(confirmpass);
        if(pass===confirmpass){
            alert("Done");
        }
        else{
            alert("Not Match");
        }
    }
    }

  return (
    <Form className='m-auto mt-5' style={{width:"50%"}}> 
    <h1 className="text-center mb-4 text-success" style={{width: "100%" }}>REGISTER PAGE</h1>
        <Form.Group as={Row} className="mb-3" controlId="formFirstName">
            <Form.Label column sm="5">
                First Name
            </Form.Label>
            <Col sm="7">
                <Form.Control required name='fname' type="text" placeholder="Enter First Name" value={fname} onChange={(e)=>setFName(e.target.value)} />
                <span style={{ color: "red" }}>{errors["fname"]}</span>
            </Col>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formLastName">
            <Form.Label column sm="5">
                Last Name
            </Form.Label>
            <Col sm="7">
                <Form.Control required name='lname' type="text" placeholder="Enter Last Name" value={lname} onChange={(e)=>setLName(e.target.value)} />
                <span style={{ color: "red" }}>{errors["lname"]}</span>
            </Col>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formContact">
            <Form.Label column sm="5">
                Contact Number
            </Form.Label>
            <Col sm="7">
                <Form.Control type="tel" required value={contact} onChange={(e)=>setContact(e.target.value)} />
                <span style={{ color: "red" }}>{errors["contact"]}</span>
            </Col>
      </Form.Group>
      <Form.Group as={Row} required className="mb-3" controlId="formGender">
            <Form.Label column sm="5">
                Gender
            </Form.Label>
            <Col sm="2" className='mt-2'>
            <Form.Check type='radio' id={`male`} label={`Male`} name="gender"
            defaultChecked={gender === "Male"} 
            onClick={(e)=>setGender(e.target.value)} value="Male" >Male</Form.Check>
            </Col>
            <Col sm="2" className='mt-2'>
            <Form.Check type='radio' id={`female`} label={`Female`} name="gender"
            defaultChecked={gender === "Female"} 
            onClick={(e)=>setGender(e.target.value)} value="Female" />
            </Col>
            <Col sm="2" className='mt-2'>
            <Form.Check type='radio' id={`Others`} label={`Others`} name="gender"
            defaultChecked={gender === "Others"} 
            onClick={(e)=>setGender(e.target.value)} value="Female" />
            </Col>
            <span style={{ color: "red" }}>{errors["gender"]}</span>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formUserType">
            <Form.Label column sm="5">
                User Category
            </Form.Label>
            <Col sm="7">
                <Form.Select required onChange={(e)=>setUserType(e.target.value)}>
                    <option value="ADMIN">ADMIN</option>
                    <option value="Custmer">CUSTMER</option>
                </Form.Select>
            </Col>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formUserId">
            <Form.Label column sm="5">
                Username
            </Form.Label>
            <Col sm="7">
                <Form.Control required type="text" placeholder="Enter Username" vlaue={userid} onChange={(e)=>setUserId(e.target.value)}/>
                <span style={{ color: "red" }}>{errors["userid"]}</span>
            </Col>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formPass">
            <Form.Label column sm="5">
                Password
            </Form.Label>
            <Col sm="7">
                <Form.Control required type="password" placeholder="Enter Password" vlaue={pass} onChange={(e)=>setPass(e.target.value)}/>
                <span style={{ color: "red" }}>{errors["pass"]}</span>
            </Col>
      </Form.Group>
      <Form.Group as={Row} className="mb-3" controlId="formConfirmPass">
            <Form.Label column sm="5">
                Confirm Password
            </Form.Label>
            <Col sm="7">
                <Form.Control required type="password" placeholder="Confirm Password" vlaue={confirmpass} onChange={(e)=>setConfirmPass(e.target.value)}/>
                <span style={{ color: "red" }}>{errors["confirmpass"]}</span>
            </Col>
      </Form.Group>

      <Form.Group as={Row} className="mb-3" controlId="formSubmit">
            <Col sm="6">
                <Button className="col-12 btn-success" type="submit" value="submit"  onClick={handleSubmit}> Submit </Button>
            </Col>
            <Col sm="6">
                <Link className='btn btn-success col-12' to="/login">Cancel</Link>
            </Col>
      </Form.Group>
    
  </Form>
  )
}

export default AdminRegister;