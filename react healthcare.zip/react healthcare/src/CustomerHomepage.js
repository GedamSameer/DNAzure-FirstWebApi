
import React,{useState} from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import {Form,Row,Col,Button,Navbar,Container,NavDropdown,Nav} from 'react-bootstrap';
import SearchMedicine from "./SearchMedicine";
import OrderMedicine from "./OrderMedicine"
const CustomerHomepage =()=>{
    const [user,setUser] = useState("");
    useEffect(()=>{
        if(user==="Search")
        {
            <SearchMedicine />
        }
    })
    let check;
    if(user==="Search")
    {
      check =  <SearchMedicine/>
    }
    else if(user==="Order"){
        check = <OrderMedicine/>
    }
    else{
        
     
    }
    return(
      <>
      <Navbar className="bg-light p-1">
  <Container>
    <Navbar.Brand className="text-dark " href="#SearchMedicine"><h1>Customer Dashboard</h1></Navbar.Brand>
    <Navbar.Toggle />
    <Navbar.Collapse className="justify-content-end">
      
        <Button className="mx-2" variant="warning" type='button' id={`Search`} label={`Search`}  name="user"

        defaultChecked={user === "Search"}

        onClick={(e)=>setUser(e.target.value)} value="Search"><b>Search Medicine</b></Button>
 

        <Button className="mx-2" variant="warning"type='button' id={`Order`} label={`Order`} name="user"

        defaultChecked={user === "Order"}

        onClick={(e)=>setUser(e.target.value)} value="Order"><b>Order Medicine</b></Button>

<Button className="mx-2" variant="danger" type='button' id={`Logout`} label={`Search`}  name="user" href="./"

defaultChecked={user === "Logout"}
 value="Search">Logout</Button>


     
    </Navbar.Collapse>
  </Container>
</Navbar>
 

<div className="text-center">

    
     
        {
           check
        }
  </div>
</>
    );
}
export default CustomerHomepage