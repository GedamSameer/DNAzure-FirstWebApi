import React, { Component } from 'react';
import { Button, Nav, Table, Form, Navbar, Container } from 'react-bootstrap';
import MedicineModal from "./MedicineModel"

class AvailableMedicine extends Component {
    constructor(props) {
        super(props);
        this.state = {
            helpData: [],
            des: "",
            showHelpModel: false,
            updateModalData: []
        };
    }
    refreshData() {
        fetch("http://localhost:5284/api/Medicines").then(response => response.json()).then(data => this.setState({ helpData: data }));
    }
    componentDidMount() {
        this.refreshData();
    }
    componentDidUpdate() {
        this.refreshData();
    }
    showDetails = (e, record) => {
        console.log(record);
        this.setState({ updateModalData: record })
        this.setState({ showHelpModel: true });
    }




    render() {



        let back = () => window.location = `/${sessionStorage.getItem("userType").toLowerCase()}dashboard`



        const data = this.state.helpData;
        let closeHelpModel = () => { this.setState({ showHelpModel: false }) }
        return (
            <>
                <Navbar className="bg-light p-1">
                    <Container>
                        <Navbar.Brand className="text-dark "><h1>Available Medicine</h1></Navbar.Brand>
                        <Button variant="dark" href="./AdminHomepage" className='float-end btn-success mx-3' onClick={back} > Back </Button>
                    </Container>
                </Navbar>





                <Form className="m-auto mt-5" style={{ width: "50%" }}>
                    <h2 className="text-center mb-4 text-primary" style={{ width: "100%" }}>
                        Available Medicine List {sessionStorage.getItem("userType")}
                    </h2>





                </Form>
                <Table className='mt-4 text-white' variant="dark" bordered size='sm'>



                    <thead>
                        <tr><th colSpan={9} className="text-white text-center">Available Medicine Requested</th></tr>
                        <tr ><th>Id</th>
                            <th>Medicine Name</th>
                            <th>Manufacturer</th>
                            <th>Quantity per strip</th>
                            <th>MRP per quantity</th>
                            <th>Manufacturing Date</th>
                            <th>Expiry Date</th>
                            <th>Type</th>
                            <th>Available Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        {data.map(record => {
                            {
                                return (<tr key={record.id}>
                                    <td><Button className='btn btn-link text-dark text-decoration-none' variant='link' variant='primary' onClick={(e) => this.showDetails(e, record)}>{record.id}</Button></td>
                                    <td>{record.medicineName}</td>
                                    <td>{record.manufacturer}</td>
                                    <td>{record.quantityPerStripPac}</td>
                                    <td>{record.mrpForEachQuantity}</td>
                                    <td>{record.manufacturingDate}</td>
                                    <td>{record.expiryDate}</td>
                                    <td>{record.type}</td>
                                    <td>{record.availableQuantity}</td>



                                </tr>)
                            }
                        }
                        )}
                    </tbody>
                </Table>
                <Button variant="light" href="./AddMedicine" className='float-center btn-success mx-7' onClick={back} > Add Medicine </Button>
                <MedicineModal
                    data={this.state.updateModalData}
                    show={this.state.showHelpModel}
                    onHide={closeHelpModel}
                />
            </>



        );





    }
}





export default AvailableMedicine;