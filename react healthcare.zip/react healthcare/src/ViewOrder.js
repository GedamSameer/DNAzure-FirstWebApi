import React, { Component } from 'react';
import { Button, Nav, Table, Form, Navbar, Container } from 'react-bootstrap';



class ViewOrder extends Component {
constructor(props) {
super(props);
this.state = {
helpData: [],
des: "",
showHelpModel: false
};
}
refreshData() {
fetch("http://localhost:5284/api/Orders").then(response => response.json()).then(data => this.setState({ helpData: data }));
}
componentDidMount() {
this.refreshData();
}
componentDidUpdate() {
this.refreshData();
}





render() {



let back = () => window.location = `/${sessionStorage.getItem("userType").toLowerCase()}dashboard`



const data = this.state.helpData;
let closeHelpModel = () => { this.setState({ showHelpModel: false }) }
return (
<>






<Form className="m-auto mt-5" style={{ width: "50%" }}>
<h2 className="text-center mb-4 text-white" style={{ width: "100%" }}>
View List Order {sessionStorage.getItem("userType")}
</h2>





</Form>
<Table className='mt-4 text-white' variant="dark" bordered size='sm'>



<thead>
<tr><th colSpan={9} className="text-white text-center">Available Medicine Requested</th></tr>
<tr><th>Id</th>
<th>Patient Name</th>
<th>Age</th>
<th>Doctor Name</th>
<th>Date Of Order</th>
<th>Medicine</th>
<th>Required Quantity</th>
</tr>
</thead>
<tbody>
{data.map(record => { {
return (<tr key={record.id}>
<td>{record.id}</td>
<td>{record.patientName}</td>
<td>{record.age}</td>
<td>{record.doctorName}</td>
<td>{record.dateOfOrder}</td>
<td>{record.medicine}</td>
<td>{record.requiredQuantity}</td>



</tr>)
}
}
)}
</tbody>
</Table>

</>



);





}
}





export default ViewOrder;