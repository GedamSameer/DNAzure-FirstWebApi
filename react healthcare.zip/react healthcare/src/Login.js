import React, { Component, useState } from "react";
import { Form, Button,ButtonToolbar,Row ,Col} from "react-bootstrap";

import { Link } from "react-router-dom";
import ForgetUserId from "./ForgetUserId";
import ForgetPassword from "./ForgotPassword";
export default class Login extends Component {
  constructor(props) {
    super(props);
    this.state = {
      email: "",
      pass: "",
      showForgetUserIdShow: false,
      showForgetPasswordShow: false
    };
  }

  buttonClick = async (e) => {
    e.preventDefault();
  };
  render() {
    let showModelClose =()=>this.setState({showForgetUserIdShow:false});
    let showPassModelClose =()=>this.setState({showForgetPasswordShow:false});

    return (
      <Form className="m-auto mt-12 my-auto justify-Content" style={{ width: "50%",height: "100vh"}}>
         <h1 className="text-center mb-4 text-success" style={{width: "100%" }}>LOGIN PAGE</h1>
        <Form.Group className="mb-3 col-12" controlId="formBasicEmail">
          <Form.Label>EMAIL ADDRESS</Form.Label>
          <Form.Control
            type="email"
            required
            placeholder="Enter email"
            value={this.state.email}
            name="email"
            onChange={(e) => {
              this.setState({ email: e.target.value });
            }}
          />
        </Form.Group>

        <Form.Group className="mb-3 col-12" controlId="formBasicPassword">
          <Form.Label>PASSWORD</Form.Label>
          <Form.Control
            type="password"
            required
            placeholder="Password"
            value={this.state.pass}
            name="pass"
            onChange={(e) => {
              this.setState({ pass: e.target.value });
            }}
          />
        </Form.Group>
        <div className="row m-2">
          <Button
            className="col-4 btn-success"
            variant="primary"
            type="submit "
            onClick={this.buttonClick}
          >
            Login
          </Button>
          <div className="col-4"></div>
          <Button className="col-4 ml-5 btn-success" variant="primary" type="reset">
            Cancel
          </Button>
        </div>
        <div className="row mb-2">
          <Form.Group controlId="formBasicPassword">   
          <Row> 
            <Col className="p-0 col-5">     
            <Button
            variant="link"
              className="link-primary"
              onClick={() => this.setState({ showForgetUserIdShow: true })}>
              Forgot UserId?              
            </Button>
            <ForgetUserId
                show={this.state.showForgetUserIdShow}
                onHide={showModelClose}
              />     
              </Col>
              <Col className="p-1 col-6">    
            <Button        
            variant="link"  
              className="link-primary"
              onClick={() => this.setState({ showForgetPasswordShow: true })}
            >
              Forgot Password?
              
            </Button>

            <ForgetPassword
                show={this.state.showForgetPasswordShow}
                onHide={showPassModelClose}
              />    
              </Col>
              </Row>     
          </Form.Group>
        </div>

        <Link className="btn btn-success col-12" to="/register">
          Register
        </Link>
      </Form>
    );
  }
}