import React,{useState} from "react";
import { Link } from "react-router-dom";
import {Form,Row,Col,Button,Navbar,Container} from 'react-bootstrap'
import { useEffect } from "react";
import AdminRegister from "./AdminRegister";
import CustomerRegister from "./CustomerRegister";
import {Carouse} from 'react-bootstrap'
import "./Homepage.css";
const Homepage = () =>{
    const [user,setUser] = useState("");

    useEffect(()=>{
        if(user==="Admin")
        {
            <AdminRegister />
        }
    })
  
    let check;
    if(user==="Admin")
    {
      check =  <AdminRegister />
    }
    else if(user==="Customer"){
        check = <CustomerRegister />
    }
    else{
      check= <div style={{width:"100wh",height:"100vh"}} ></div>
    }
    return(
      <>
      <Navbar className="bg-light p-2">
  <Container>
    <Navbar.Brand className="text-dark " href="#home"><h1> <i>Welcome to Healthcare Pharma Payment</i></h1></Navbar.Brand>
    <Navbar.Toggle />
    <Navbar.Collapse className="justify-content-end">
      
      <Form className='mt-32 d-flex flex-row-reverse' style={{width:"40%"}}>

<Form.Group as={Row} required className="" controlId="formGender">

        <Col sm="6" className='  text-center'>

        <Button variant='warning' type='button' id={`Admin`} label={`ADMIN`}  name="user"

        defaultChecked={user === "Admin"}

        onClick={(e)=>setUser(e.target.value)} value="Admin"><b>Admin</b> </Button>
 

        </Col>

        <Col sm="2" className=''>

        <Button variant='warning' type='button' id={`Customer`} label={`CUSTOMER`} name="user"

        defaultChecked={user === "Customer"}

        onClick={(e)=>setUser(e.target.value)} value="Customer"><b>Customer </b></Button>

        </Col>
    
  </Form.Group>

    </Form>
     
    </Navbar.Collapse>
  </Container>
</Navbar>
 

<div className="text-center">

    
     
        {
           check
        }
  </div>
</>
    );
};
export default Homepage;