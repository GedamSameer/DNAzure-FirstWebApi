import React, { useState } from 'react'
import { Form, Button, Row, Col, Container } from 'react-bootstrap'
import { Link } from 'react-router-dom'
import AdminSecretQuestions from './AdminSecretQuestions';
import validator from 'validator';

function AdminRegister() {

    const [showSecreteQue, setShowSecreteQue] = useState(false);
    const [fname, setFName] = useState("");
    const [lname, setLName] = useState("");
    const [age, setAge] = useState("");
    const [contact, setContact] = useState("");
    const [gender, setGender] = useState("Male");
    const [emailid, setEmailId] = useState("");
    const [adminid, setAdminId] = useState("");
    const [confirmpass, setConfirmPass] = useState("");
    const [pass, setPass] = useState("");
    const [errors, setErros] = useState({});

    const resetForm = () => {
        setShowSecreteQue(false);
        setFName("");
        setLName("");
        setAge("");
        setContact("");
        setGender("Male");
        setEmailId("");
        setAdminId("");
        setConfirmPass("");
        setPass("");
        setErros({});

    }
    const getUsername = async () => {
        let usernames = await fetch("http://localhost:5284/api/Admins",
            {
                method: "GET",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            })
            .then(res => res.json())
            .then(result => result);
        return await usernames;
    }

    const handleValidation = async () => {

        let errors = {};
        let formIsValid = true;

        if (typeof fname !== "undefined") {
            if (!fname) {
                formIsValid = false;
                errors["fname"] = "Please, Enter a Value";
            }
            else if (!fname.match(/^[A-Za-z]*$/)) {
                formIsValid = false;
                errors["fname"] = "Only letters";
            }
        }
        if (typeof lname !== "undefined") {
            if (!lname) {
                formIsValid = false;
                errors["lname"] = "Please, Enter a Value";
            }
            else if (!lname.match(/^[A-Za-z]*$/)) {
                formIsValid = false;
                errors["lname"] = "Only letters";
            }
        }

        if (typeof age !== "undefined") {
            if (!age) {
                formIsValid = false;
                errors["age"] = "Please, Enter a Value";
            }
            else if (!age.match(/^[0-9]*$/)) {
                formIsValid = false;
                errors["age"] = "Only Numbers";
            }

        }
        if (typeof contact !== "undefined") {
            if (!contact) {
                formIsValid = false;
                errors["contact"] = "Please, Enter a Value";
            }
            else if (!contact.match(/^[0-9]*$/)) {
                formIsValid = false;
                errors["contact"] = "Only numbers";
            }
            else if (contact.length !== 10) {
                formIsValid = false;
                errors["contact"] = "10 Digit number is required";
            }
        }
        if (typeof emailid !== "undefined") {
            if (!emailid) {
                formIsValid = false;
                errors["emailid"] = "Please, Enter a Value";
            }
            else if (!validator.isEmail(emailid)) {
                formIsValid = false;
                errors["emailid"] = "Enter a valid Email";
            }
        }
        if (typeof adminid !== "undefined") {
            if (!adminid) {
                formIsValid = false;
                errors["adminid"] = "Please, Enter a Value";
            }
        }
        if (typeof pass !== "undefined") {
            if (!pass) {
                formIsValid = false;
                errors["pass"] = "Please, Enter a Value";
            }
        }
        if (typeof confirmpass !== "undefined") {
            if (!confirmpass) {
                formIsValid = false;
                errors["confirmpass"] = "Please, Enter a Value";
            }
            else if (pass !== confirmpass) {
                formIsValid = false;
                errors["confirmpass"] = "Confirm pass should be equal to password";
            }
        }

        let usernaslist = await getUsername();
        console.log(usernaslist)
        if (usernaslist.includes(adminid)) {
            formIsValid = false;
            errors["adminid"] = "Admin already present";
        }
        setErros(errors);
        return await formIsValid;
    }
    let showModelClose = () => setShowSecreteQue(false);
    return (
        <>
          
            <Form className='m-auto float-centre mt-4' style={{ width: "80%" }}>
                <h3 className="text-center mb-4 text-dark" style={{ width: "100%" }}><u>ADMIN REGISTRATION</u></h3>
               <Container>
                <Form.Group as={Row} className="mb-3" controlId="formFirstName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start " column sm="2">
                    <b> First Name</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='fname' type="text" placeholder="Enter First Name" value={fname} onChange={(e) => setFName(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["fname"]}</span>
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formLastName">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Last Name</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='lname' type="text" placeholder="Enter Last Name" value={lname} onChange={(e) => setLName(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["lname"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formAge">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Age</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required name='age' type="Number" placeholder="Enter Age" value={age} onChange={(e) => setAge(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["age"]}</span>
                    </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formContact">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Contact Number</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control type="tel" placeholder="Enter Contact Number" required value={contact} onChange={(e) => setContact(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["contact"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} required className="mb-3" controlId="formGender">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b> Gender</b>
                    </Form.Label>
                    <Col sm="1" className='mt-2'>
                        <Link to="/AdminRegister">
                            <Form.Check type='radio' id={`Male`} label="Male" name="gender"
                                defaultChecked={gender === "Male"}
                                onClick={(e) => setGender(e.target.value)} value="Male" />
                        </Link>
                    </Col>
                    <Col sm="1" className='mt-2'>
                        <Form.Check type='radio' id={`female`} label={`Female`} name="gender"
                            defaultChecked={gender === "Female"}
                            onClick={(e) => setGender(e.target.value)} value="Female" />
                    </Col>
                    <Col sm="1" className='mt-2'>
                       <Form.Check type='radio' id={`Others`} label={`Others`} name="gender"
                            defaultChecked={gender === "Others"}
                            onClick={(e) => setGender(e.target.value)} value="Female" />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["gender"]}</span>
                    </Col>
                    <Form.Label column sm="2">
                    </Form.Label>

                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formEmailId">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>  Email Id</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="email" placeholder="Enter Email Id" value={emailid} onChange={(e) => setEmailId(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["emailid"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formCustomerId">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>  Admin Id</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="text" placeholder="Enter Admin Id" value={adminid} onChange={(e) => setAdminId(e.target.value)} />
                    </Col>
                    <Col sm="2">

                        <span style={{ color: "red" }}>{errors["adminid"]}</span>
                    </Col>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formPass">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>Password</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="password" placeholder="Enter Password" vlaue={pass} onChange={(e) => setPass(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["pass"]}</span>
                    </Col>

                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formConfirmPass">
                    <Form.Label column sm="3">
                    </Form.Label>
                    <Form.Label className="d-flex justify-content-start" column sm="2">
                    <b>   Confirm Password</b>
                    </Form.Label>
                    <Col sm="5">
                        <Form.Control required type="password" placeholder="Confirm Password" vlaue={confirmpass} onChange={(e) => setConfirmPass(e.target.value)} />
                    </Col>
                    <Col sm="2">
                        <span style={{ color: "red" }}>{errors["confirmpass"]}</span>
                    </Col>
                </Form.Group>

                <Form.Group as={Row} className="mb-3" controlId="formSubmit">
                    <Form.Label column sm="4">
                    </Form.Label>
                    <Col sm="3">
                        <Button className="col-12 btn-dark" type="submit" value="submit" onClick={async (e) => {
                            e.preventDefault(); if (await handleValidation()) { setShowSecreteQue(true) }
                        }}> <b>Register</b> </Button>
                        <AdminSecretQuestions
                            show={showSecreteQue}
                            onHide={showModelClose}
                            data={{
                                "id": 0,
                                "firstName": fname,
                                "lastName": lname,
                                "age": age,
                                "contactNo": contact,
                                "gender": gender,
                                "emailId": emailid,
                                "adminId": adminid,
                                "password": pass,
                            }
                            } />
                    </Col>
                    <Col sm="3">
                        <Button className='btn btn-danger col-12' onClick={resetForm}><b>Reset</b></Button>
                    </Col>
                    <Form.Label column sm="2">
                    </Form.Label>
                </Form.Group>
                <Form.Group as={Row} className="mb-3" controlId="formSignin">
                    <Form.Label column sm="3">
                    </Form.Label>

                    <Form.Label className="d-flex justify-content-start" column sm="4">
                       <b> Already have an account?</b><pre>    </pre>
                        <Link type="signin" value="Sign in" to="/AdminSignin"> <b>Sign in </b></Link>
                    </Form.Label>
                </Form.Group>
                </Container>
            </Form>
        </>
    );
}

export default AdminRegister

