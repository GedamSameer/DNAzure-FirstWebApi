import React, { Component } from "react";
import { Modal, Button, Row, Col, Form } from "react-bootstrap";
class MedicineModal extends Component {
  constructor(props) {
    super(props);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      medicinename: this.props.data.medicineName,
      manufacturer: this.props.data.manufacturer,
      quantityperstrip: this.props.data.quantityPerStripPac,
      mrpperquantity: this.props.data.mrpForEachQuantity,
      manufacturingdate: this.props.data.manufacturingDate,
      expirydate: this.props.data.expiryDate,
      type: this.props.data.type,
      availablequantity: this.props.data.availableQuantity,
      errors: {},
      count:0
    };
  }
  componentDidUpdate (prevProps,prevState){
      if(prevProps!==this.props){
          if(this.props.data.manufacturingDate!==undefined && this.state.count===0){
                    this.setState({
        medicinename: this.props.data.medicineName,
        manufacturer: this.props.data.manufacturer,
        quantityperstrip: this.props.data.quantityPerStripPac,
        mrpperquantity: this.props.data.mrpForEachQuantity,
        manufacturingdate: this.props.data.manufacturingDate.split('T')[0],
        expirydate: this.props.data.expiryDate.split('T')[0],
        type: this.props.data.type,
        availablequantity: this.props.data.availableQuantity,
        count:1})
                                
      }
      
    }
  }
  setDate = (separator = "-") => {
    let newDate = new Date();
    let date = newDate.getDate();
    let month = newDate.getMonth() + 1;
    let year = newDate.getFullYear();

    return `${year}${separator}${
      month < 10 ? `0${month}` : `${month}`
    }${separator}${date}`;
  };

  handleValidation = () => {
    let errors = {};
    let formIsValid = true;

    if (typeof this.state.medicinename !== "undefined") {
      if (!this.state.medicinename) {
        formIsValid = false;
        errors["medicinename"] = "Please, Enter a Value";
      }
    }
    if (typeof this.state.manufacturer !== "undefined") {
      if (!this.state.manufacturer) {
        formIsValid = false;
        errors["manufacturer"] = "Please, Enter a Value";
      }
    }

    if (typeof this.state.quantityperstrip !== "undefined") {
      if (!this.state.quantityperstrip) {
        formIsValid = false;
        errors["quantityperstrip"] = "Please, Enter a Value";
      } else if (!this.state.quantityperstrip.match(/^[0-9]*$/)) {
        formIsValid = false;
        errors["quantityperstrip"] = "Only Numbers";
      }
    }
    if (typeof this.state.mrpperquantity !== "undefined") {
      if (!this.state.mrpperquantity) {
        formIsValid = false;
        errors["mrpperquantity"] = "Please, Enter a Value";
      } else if (!this.state.mrpperquantity.match(/^[0-9]*$/)) {
        formIsValid = false;
        errors["mrpperquantity"] = "Only numbers";
      }
    }
    if (typeof this.state.manufacturingdate !== "undefined") {
      if (!this.state.manufacturingdate) {
        formIsValid = false;
        errors["manufacturingdate"] = "Please, Enter a Value";
      }
    }
    if (typeof this.state.expirydate !== "undefined") {
      if (!this.state.expirydate) {
        formIsValid = false;
        errors["expirydate"] = "Please, Enter a Value";
      }
    }
    if (typeof this.state.type !== "undefined") {
      if (!this.state.type) {
        formIsValid = false;
        errors["type"] = "Please, Enter a Value";
      }
    }
    if (typeof this.state.availablequantity !== "undefined") {
      if (!this.state.availablequantity) {
        formIsValid = false;
        errors["availablequantity"] = "Please, Enter a Value";
      } else if (!this.state.availablequantity.match(/^[0-9]*$/)) {
        formIsValid = false;
        errors["availablequantity"] = "Only numbers";
      }
    }

    this.setState({ errors: errors });
    return formIsValid;
  };
  handleSubmit =async  (e) => {
    e.preventDefault();
    if (this.handleValidation) {
        let obj ={                        
            id: this.props.data.id,
            medicineName: this.state.medicinename,
            manufacturer: this.state.manufacturer,
            quantityPerStripPac: this.state.quantityperstrip,
            mrpForEachQuantity: this.state.mrpperquantity,
            manufacturingDate: this.state.manufacturingdate,
            expiryDate: this.state.expirydate,
            type: this.state.type,
            availableQuantity: this.state.availablequantity,
          }
      await fetch(`http://localhost:5284/api/Medicines/${this.props.data.id}`,{      
      method: "PUT",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
        },
        body: JSON.stringify(obj),
      })
      window.location = "/AvailableMedicine"
    }
  };
  render() {
    return (
      <div className="container">
        <Modal {...this.props} size="lg" centered>
          <Modal.Header closeButton>
            <Modal.Title>Medicine Update</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <Form className="m-auto float-centre mt-5" style={{ width: "80%" }}>
              <h1
                className="text-center mb-4 text-primary"
                style={{ width: "100%" }}
              > Update Medicine
              </h1>
              <Form.Group as={Row} className="mb-3" controlId="formFirstName">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Medicine Name
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    required
                    name="medicinename"
                    type="text"
                    placeholder="Enter Medicine Name"
                    value={this.state.medicinename}
                    onChange={(e) => {this.setState({medicinename:e.target.value});console.log(this.state.medicinename)}}
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>{this.state.errors["medicinename"]}</span>
                </Col>
              </Form.Group>
              <Form.Group as={Row} className="mb-3" controlId="formLastName">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Manufacturer
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    required
                    name="manufacturer"
                    type="text"
                    placeholder="Enter Manufacturer"
                    value={this.state.manufacturer}
                    onChange={(e) => this.setState({manufacturer:e.target.value})}                    
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>{this.state.errors["manufacturer"]}</span>
                </Col>
              </Form.Group>
              <Form.Group as={Row} className="mb-3" controlId="formAge">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Quantity Per Strip
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    required
                    name="quantityperstrip"
                    type="Number"
                    placeholder="Enter Quantity Per Strip"
                    value={this.state.quantityperstrip}
                    onChange={(e) => this.setState({quantityperstrip:e.target.value})}
                    
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>
                    {this.state.errors["quantityperstrip"]}
                  </span>
                </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formContact">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  MRP Per Quantity
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    type="Number"
                    placeholder="Enter MRP Per Quantity"
                    required
                    value={this.state.mrpperquantity}
                    onChange={(e) => this.setState({mrpperquantity:e.target.value})}
                    
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>
                    {this.state.errors["mrpperquantity"]}
                  </span>
                </Col>
              </Form.Group>
              <Form.Group
                as={Row}
                required
                className="mb-3"
                controlId="formGender"
              >
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Manufacturing Date
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    type="Date"
                    name="manufacturingdate"
                    max={this.setDate()}
                    required
                    value={this.state.manufacturingdate}
                    onChange={(e) => this.setState({manufacturingdate:e.target.value})}
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>
                    {this.state.errors["manufacturingdate"]}
                  </span>
                </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formEmailId">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Expiriy Date
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    type="Date"
                    name="expirydate"
                    min={this.setDate()}
                    required
                    value={this.state.expirydate}
                    onChange={(e) => this.setState({expirydate:e.target.value})}
                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>{this.state.errors["expirydate"]}</span>
                </Col>
              </Form.Group>
              <Form.Group as={Row} className="mb-3" controlId="formPass">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Available Quantity
                </Form.Label>
                <Col sm="5">
                  <Form.Control
                    required
                    type="Number"
                    placeholder="Enter Available Quantity"
                    value={this.state.availablequantity}
                    onChange={(e) => this.setState({availablequantity:e.target.value})}

                  />
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>
                    {this.state.errors["availablequantity"]}
                  </span>
                </Col>
              </Form.Group>
              <Form.Group as={Row} className="mb-3" controlId="formPass">
                <Form.Label column sm="3"></Form.Label>
                <Form.Label
                  className="d-flex justify-content-start"
                  column
                  sm="2"
                >
                  Medicine Type
                </Form.Label>
                <Col sm="5">
                  <Form.Select
                    required
                    value={this.state.type}
                    onChange={(e) => this.setState({type:e.target.value})}
                  >
                    <option value="Capsule">Capsule</option>
                    <option value="Tablet">Tablet</option>
                    <option value="Liquid">Liquid</option>
                    <option value="Gas">Gas</option>
                    <option value="Other">Other</option>
                  </Form.Select>
                </Col>
                <Col sm="2">
                  <span style={{ color: "red" }}>
                    {this.state.errors["type"]}
                  </span>
                </Col>
              </Form.Group>

              <Form.Group as={Row} className="mb-3" controlId="formSubmit">
                <Form.Label column sm="4"></Form.Label>
                <Col sm="3">
                  <Button
                    className="col-12 btn-success"
                    type="submit"
                    value="submit"
                    onClick={(e)=>this.handleSubmit(e)}
                  >
                    {" "}
                    Update{" "}
                  </Button>
                </Col>
                <Col sm="3">
                  <Button className="btn btn-danger col-12" onClick={()=>this.resetForm()}>
                    Reset
                  </Button>
                </Col>
                <Form.Label column sm="2"></Form.Label>
              </Form.Group>
            </Form>
          </Modal.Body>
        </Modal>
      </div>
    );
  }
}

export default MedicineModal;


