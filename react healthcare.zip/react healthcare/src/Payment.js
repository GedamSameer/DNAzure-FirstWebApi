import React ,{useState}from 'react';
import {Form,Button,Row,Col,Alert,Dropdown,Navbar,Container,NavDropdown,Nav,FormControl,InputGroup,SplitButton} from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.min.css";
import { Link } from 'react-router-dom';

const Payment=()=>{
  const [s,setS] = useState("")
  const btnClick = (e,type) =>{
    console.log(1)
    setS(<div className='alert alert-success' role={"alert"}>
      Payemnt Done Successfully with {type} <Link type="signin" value="Sign in" to="/CustomerHomepage"><b>  Continue Shopping </b> </Link>
    </div>)
  }
  return(
    <>
   <Navbar className="bg-light p-1">
          <Container>
            <Navbar.Brand className="text-dark" ><h1>Payment </h1></Navbar.Brand>
           
            <Button  variant="dark" href="./OrderMedicine" className='float-end btn-success mx-3' > Back </Button>
          </Container>
        </Navbar>
        <div>
<Form className="m-auto mt-1" style={{ width: "40%" }}>

  <Row>
  
    <Col sm="6" className=''>
      <Button variant='light' type='button' id={`Search`} label={`Search`} onClick={(e)=>btnClick(e,"Net Banking")} ><b>Net Banking</b></Button>
    </Col>

    <Col sm="4" className=''>
      <Button variant='light'type='button' id={`Order`} label={`Order`}  onClick={(e)=>btnClick(e,"COD")}><b>COD</b></Button>
    </Col>

    <Col sm="2" className=''>
      <Button variant='light'type='button' id={`Order`} label={`Order`}  onClick={(e)=>btnClick(e,"UPI")}><b>UPI</b></Button>
    </Col>
  </Row>

</Form>

{s}
</div>
    

  
</>
  )
}
export default Payment