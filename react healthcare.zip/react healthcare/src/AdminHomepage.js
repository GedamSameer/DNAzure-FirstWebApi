
import React,{useState} from "react";
import { useEffect } from "react";
import { Link } from "react-router-dom";
import {Form,Row,Col,Button,Navbar,Container,NavDropdown,Nav} from 'react-bootstrap';
import SearchMedicine from "./SearchMedicine";
import OrderMedicine from "./OrderMedicine"
import Homepage from "./Homepage";
import AvailableMedicine  from "./AvailableMedicine";  
import ViewOrder from "./ViewOrder";

const AdminHomepage =()=>{
    const [user,setUser] = useState("");
    useEffect(()=>{
        if(user==="Search")
        {
          
            <AvailableMedicine />
        }
    })
    let check;
    if(user==="Search")
    {
      window.location="/AvailableMedicine"
    }
    else if(user==="Order"){
        check = <ViewOrder/>
    }
    const logoutClick = (e) => {
        window.location = "./"
      }
    return(
      <>
      <Navbar className="bg-light p-1">
  <Container>
    <Navbar.Brand className="text-dark " href="#SearchMedicine"><h1>Admin Dashboard</h1></Navbar.Brand>
    <Navbar.Toggle />
    <Navbar.Collapse className="justify-content-end">
        
        <Col sm="1" className=''>

        <Button variant="danger" type='button' id={`Logout`} label={`Search`}  name="user"

        defaultChecked={user === "Logout"}

        onClick={(e)=>logoutClick()} value="Search">Logout</Button>
 

        </Col>
     
    </Navbar.Collapse>
    
  </Container>
</Navbar>
 

<div className="text-center">

<div>
<Form className="m-auto mt-1" style={{ width: "40%" }}>
<Container className="bg-dark text-light">
  <Row>
  
    <Col sm="6" className=''>
      <Button variant='dark' type='button' id={`Search`} label={`Search`} name="user"
        defaultChecked={user === "Search"}
        onClick={(e) => setUser(e.target.value)} value="Search"><b>Medicine Information</b></Button>
    </Col>

    <Col sm="6" className=''>
      <Button variant='dark'type='button' id={`Order`} label={`Order`} name="user"
        defaultChecked={user === "Order"}
        onClick={(e) => setUser(e.target.value)} value="Order"><b>View Order</b></Button>
    </Col>
  </Row>
</Container>
</Form>

</div>
    
     
        {
           check
        }
  </div>
</>
    );
}
export default AdminHomepage